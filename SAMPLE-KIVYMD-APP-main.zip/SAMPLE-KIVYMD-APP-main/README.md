# SAMPLE-KIVYMD-APP
The sample kivy and kivymd app to apk conversion.
